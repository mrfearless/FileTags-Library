.. _FileTagsFree:

============
FileTagsFree
============

Uninitialize COM for FileTags functions.

::

   FileTagsFree PROTO 


**Parameters**


**Returns**

None.


**See Also**

:ref:`FileTagsInit<FileTagsInit>`
