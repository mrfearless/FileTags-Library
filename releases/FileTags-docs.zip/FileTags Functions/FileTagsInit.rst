.. _FileTagsInit:

============
FileTagsInit
============

Initialize COM for FileTags functions.

::

   FileTagsInit PROTO 


**Parameters**


**Returns**

Return values from CoInitializeEx.


**See Also**

:ref:`FileTagsFree<FileTagsFree>`
