.. FileTags Library documentation master file

Welcome to FileTags Library's documentation!
==============================================

.. toctree::
   :maxdepth: 4
   :caption: Contents:
  
   Introduction/index
   FileTags Functions/index
    

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
